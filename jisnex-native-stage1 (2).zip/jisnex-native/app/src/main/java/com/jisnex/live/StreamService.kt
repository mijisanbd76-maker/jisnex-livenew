package com.jisnex.live

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import com.pedro.common.ConnectChecker
import com.pedro.library.rtmp.RtmpDisplay

class StreamService : Service() {
    private var display: RtmpDisplay? = null

    private val checker = object : ConnectChecker {
        override fun onConnectionStarted(url: String) {}
        override fun onConnectionSuccess() {}
        override fun onConnectionFailed(reason: String) { stopSelf() }
        override fun onNewBitrate(bitrate: Long) {}
        override fun onDisconnect() {}
        override fun onAuthError() {}
        override fun onAuthSuccess() {}
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i == null || i.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        val hasMic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("live", "Live", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(this, 0, Intent(this, StreamService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "live").setContentTitle("JISNEX Live is streaming")
            .setSmallIcon(android.R.drawable.presence_video_online)
            .addAction(Notification.Action.Builder(null, "STOP", stopPi).build()).build()
        if (Build.VERSION.SDK_INT >= 29) {
            var t = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            if (hasMic) t = t or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            startForeground(1, n, t)
        } else startForeground(1, n)

        val d = RtmpDisplay(this, true, checker)
        d.setIntentResult(i.getIntExtra("code", 0), i.getParcelableExtra("data"))
        val v = i.getBooleanExtra("vertical", true)
        val w = if (v) 720 else 1280
        val h = if (v) 1280 else 720
        val ok = d.prepareVideo(w, h, 30, 3_500_000, 0, resources.displayMetrics.densityDpi)
        val internal = i.getBooleanExtra("phoneAudio", true) && Build.VERSION.SDK_INT >= 29
        val audioOk = if (!hasMic) true
            else if (internal) d.prepareInternalAudio(128 * 1000, 44100, true)
            else d.prepareAudio(128 * 1000, 44100, true)
        if (ok && audioOk) {
            d.startStream(i.getStringExtra("url") ?: "")
            display = d
        } else stopSelf()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        display?.let { if (it.isStreaming) it.stopStream() }
        display = null
        super.onDestroy()
    }
}
