package com.jisnex.live

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    private lateinit var url: EditText
    private lateinit var key: EditText
    private lateinit var vertical: RadioButton
    private lateinit var phoneAudio: RadioButton

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("s", 0)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        url = EditText(this).apply { setText(p.getString("url", "rtmp://a.rtmp.youtube.com/live2")); hint = "RTMP URL" }
        key = EditText(this).apply {
            setText(p.getString("key", "")); hint = "Stream Key"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        vertical = RadioButton(this).apply { text = "Vertical 9:16 (Shorts / full screen)"; isChecked = true }
        val horizontal = RadioButton(this).apply { text = "Horizontal 16:9 (phone landscape)" }
        val group = RadioGroup(this).apply { addView(vertical); addView(horizontal) }
        phoneAudio = RadioButton(this).apply { text = "Audio: Phone sound (Android 10+)"; isChecked = true }
        val micAudio = RadioButton(this).apply { text = "Audio: Microphone" }
        val agroup = RadioGroup(this).apply { addView(phoneAudio); addView(micAudio) }
        val start = Button(this).apply { text = "START LIVE" }
        val stop = Button(this).apply { text = "STOP" }
        listOf(url, key, group, agroup, start, stop).forEach { root.addView(it) }
        setContentView(root)

        start.setOnClickListener {
            p.edit().putString("url", url.text.toString()).putString("key", key.text.toString()).apply()
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED && Build.VERSION.SDK_INT >= 23) {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 2)
            } else askCapture()
        }
        stop.setOnClickListener { startService(Intent(this, StreamService::class.java).setAction("STOP")) }
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) { askCapture() }

    private fun askCapture() {
        val m = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(m.createScreenCaptureIntent(), 1)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == 1 && res == RESULT_OK && data != null) {
            val i = Intent(this, StreamService::class.java)
                .putExtra("code", res).putExtra("data", data)
                .putExtra("url", url.text.toString().trimEnd('/') + "/" + key.text.toString().trim())
                .putExtra("vertical", vertical.isChecked).putExtra("phoneAudio", phoneAudio.isChecked)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            Toast.makeText(this, "Live starting... open any app now", Toast.LENGTH_LONG).show()
            moveTaskToBack(true)
        }
    }
}
